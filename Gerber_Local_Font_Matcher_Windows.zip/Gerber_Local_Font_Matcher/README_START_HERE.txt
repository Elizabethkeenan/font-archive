GERBER LOCAL FONT MATCHER — WINDOWS

1. Extract this ZIP completely (do not run it from inside the ZIP).
2. Double-click INSTALL_AND_START.bat. It installs fonttools and openpyxl into your existing Python user environment and launches the app. Internet is required for the initial pip installation only. Future scans run offline.
3. Inventory: the included Gerber_Font_Inventory.csv is already selected, with all 845 Gerber entries. You can browse to an updated XLSX tracker instead.
4. Choose the PARENT folder containing your extracted fonts (e.g. C:\Users\Administrator\Downloads). The app scans all subfolders, regardless of archive source.
5. Click "1. Scan and find matches". Scans of 200k+ fonts can take a while; subsequent scans reuse a local cache by full path, file size, and modified time.
6. Adjust Minimum similarity (recommended 78 for broad matches, 90 for stricter) and scan again to refresh matching; cached metadata isn't re-read.
7. Review the matches. Double-click to check/uncheck; use search to filter; select visible results in bulk. Scores are name-based candidate rankings only: NOT confirmation of identical outlines.
8. Click "2. ZIP selected files + manifest". The program copies ONLY selected fonts into a ZIP and writes MATCH_REPORT.csv listing Gerber names, GSF names and original paths.

DO NOT install hundreds of thousands of fonts in Windows. The app doesn't install anything.
CAUTION: Input archives may contain commercial fonts; only copy/use fonts that you have a valid license for. The script does not determine copyright/licensing or authenticate font integrity. It only selects and packages files locally.
Damaged or unreadable fonts are skipped and counted. No web requests or uploads are made during scanning.
You can stop the scan, but for very large folders cache updates are saved periodically.

Optional: if you have only extracted a subset due to Windows hard-link errors, only those present can be indexed.
