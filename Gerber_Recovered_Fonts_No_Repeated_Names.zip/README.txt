Deduplicated by internal PostScript font name. No identical binary files were found.
Some removed candidates may have distinct revisions or glyph outlines. Consult Duplicate_Review.csv and retain the original renamed ZIP as backup.
Original: 471 files; retained: 406; omitted: 65.
