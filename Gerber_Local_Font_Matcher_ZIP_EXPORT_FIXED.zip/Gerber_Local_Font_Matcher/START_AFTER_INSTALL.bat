@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (py font_matcher.py) else (python font_matcher.py)
if errorlevel 1 pause
