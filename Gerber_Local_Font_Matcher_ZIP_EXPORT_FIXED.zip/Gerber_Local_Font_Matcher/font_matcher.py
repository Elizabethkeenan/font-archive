"""Offline font inventory matching & packaging. No font installation or network access."""
import csv, os, re, sqlite3, sys, threading, queue, traceback, zipfile, hashlib, shutil
from pathlib import Path
from difflib import SequenceMatcher
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from fontTools.ttLib import TTFont, TTCollection
except ImportError:
    TTFont = None

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / 'font_scan_cache.sqlite'
EXTENSIONS = {'.ttf','.otf','.ttc','.otc'}
BLACKLIST = {'regular','normal','roman','font','fonts','the','type','pro','std','lt','mt','t','d','ak','acct','rev','urw','bt','pt'}
WEIGHTS = {'bold','black','heavy','light','medium','demi','semibold','thin','book','extrabold','ultrabold'}
WIDTHS = {'condensed','narrow','extended','expanded','compressed','wide'}
ALIASES = [('xtr','extra'),('bol','bold'),('obl','oblique'),('ita','italic'),('nar','narrow'),('reg','regular'),('med','medium'),('lig','light'),('dem','demi'),('wid','wide'),('bla','black')]

def clean_name(s):
    s = str(s or '').replace('_',' ').replace('@',' ')
    # Split PascalCase boundaries while preserving common PostScript-style names
    s = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', s)
    s = re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',s)
    s = s.lower()
    s = re.sub(r'\b(?:acct|a\.?\s*k\.?|g\s*[- ]?edge|rev(?:ision)?\.?\s*[a-z0-9]+|urw)\b', ' ', s)
    s = re.sub(r'\.(?:ttf|otf|ttc|otc|gsf)$','',s)
    s = re.sub(r'[^a-z0-9]+',' ',s).strip()
    return ' '.join(w for w in s.split() if w not in {'acct','ak','urw','rev','g','edge'})

def tokens(s):
    return [t for t in clean_name(s).split() if t not in BLACKLIST]

def name_variants(s):
    raw = clean_name(s)
    variants = {raw}
    # Common Gerber shorthand only for candidate retrieval, not automatic exact matching
    words = raw.split()
    expanded=[]
    for w in words:
        nw = w
        if len(w)>3:
            for a,b in ALIASES:
                if w.startswith(a) and w!=b:
                    nw=b+w[len(a):]
                    break
        expanded.append(nw)
    variants.add(' '.join(expanded))
    return {v for v in variants if v}

def similarity(a,b):
    aa=clean_name(a); bb=clean_name(b)
    if not aa or not bb: return 0
    if aa==bb: return 100
    ta=set(tokens(a)); tb=set(tokens(b))
    common = len(ta & tb); union = len(ta | tb)
    seq=SequenceMatcher(None,aa,bb).ratio()
    overlap=common/union if union else 0
    containment=1 if aa in bb or bb in aa else 0
    score = max(seq*0.85+overlap*0.15, overlap*0.83+seq*0.17, 0.89 if containment and min(len(aa),len(bb))>5 else 0)
    # Named weights and width variants must not be reported as strong matches when conflicting.
    for markers in [WEIGHTS,WIDTHS,{'italic','oblique'}]:
        a_spec=ta & markers; b_spec=tb & markers
        if a_spec and b_spec and not a_spec & b_spec: score -= .16
        elif (a_spec and not b_spec) or (b_spec and not a_spec): score -= .055
    return max(0,min(99,round(score*100)))

def get_names(font):
    out=[]
    table=font.get('name')
    if table:
        for i in (1,2,4,6,16,17):
            for rec in table.names:
                if rec.nameID == i:
                    try:
                        value = rec.toUnicode().strip()
                        if value and value not in out: out.append(value)
                    except Exception: pass
    return out[:18]

def read_font(path):
    if TTFont is None: raise RuntimeError('fonttools is not installed')
    names=[]
    if path.suffix.lower() in {'.ttc','.otc'}:
        coll=TTCollection(str(path),lazy=True)
        try:
            for f in coll.fonts[:20]: names.extend(get_names(f))
        finally:
            for f in coll.fonts:
                try: f.close()
                except: pass
    else:
        f=TTFont(str(path),lazy=True)
        try: names=get_names(f)
        finally: f.close()
    return list(dict.fromkeys(names))

def connect_db():
    conn=sqlite3.connect(str(DB_PATH),timeout=60)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('CREATE TABLE IF NOT EXISTS fonts (path TEXT PRIMARY KEY, size INTEGER, mtime REAL, names TEXT, error TEXT)')
    conn.commit()
    return conn

def load_inventory(path):
    # Supports CSV and XLSX. XLSX uses optional openpyxl installed by setup.
    ext=path.suffix.lower()
    if ext=='.csv':
        with open(path,encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f))
    elif ext in {'.xlsx','.xlsm'}:
        try:
            from openpyxl import load_workbook
        except ImportError:
            raise RuntimeError('Excel support requires openpyxl. Run INSTALL_AND_START.bat or use the included CSV.')
        wb=load_workbook(path,read_only=True,data_only=True)
        try:
            ws=next((s for s in wb.worksheets if s.max_row>30 and s.max_column>=2),wb.active)
            rows=list(ws.values)
        finally: wb.close()
    else: raise ValueError('Select a CSV or XLSX inventory')
    if not rows: return []
    hdr=[str(x or '').strip().lower() for x in rows[0]]
    nidx=next((i for i,h in enumerate(hdr) if h in {'font name','gerber name','original font name'} or 'font name' in h),0)
    gidx=next((i for i,h in enumerate(hdr) if 'gsf' in h and ('filename' in h or 'file' in h)),None)
    records=[]
    for row in rows[1:]:
        if not row or nidx>=len(row) or not row[nidx]: continue
        name=str(row[nidx]).strip()
        gsf=str(row[gidx]).strip() if gidx is not None and gidx<len(row) and row[gidx] else ''
        if name.lower() in {'font name','name'}: continue
        records.append({'name':name,'gsf':gsf,'clean':clean_name(name)})
    return records

def select_candidates(records, font_names, threshold, max_per_font=30):
    # Index by first meaningful token and normalized compact name; avoid O(N*M).
    token_index={}
    compact_index={}
    for j,fnames in enumerate(font_names):
        ts=set()
        for n in fnames:
            compact_index.setdefault(clean_name(n).replace(' ',''),set()).add(j)
            ts.update(tokens(n))
        for tok in ts:
            if len(tok)>2: token_index.setdefault(tok,set()).add(j)
    result=[]
    for num,r in enumerate(records):
        pool=set()
        for var in name_variants(r['name']):
            pool.update(compact_index.get(var.replace(' ',''),set()))
            for t in tokens(var):
                if len(t)>2: pool.update(token_index.get(t,set()))
        scored=[]
        for j in pool:
            scores=[(similarity(r['name'], n),n) for n in font_names[j]]
            score,best=max(scores,default=(0,''))
            if score>=threshold: scored.append((score,best,j))
        scored.sort(key=lambda q:(-q[0],q[1]))
        for score,best,j in scored[:max_per_font]:
            result.append({'gerber':r['name'],'gsf':r['gsf'],'clean':r['clean'],'score':score,'match':best,'font_id':j})
    return result

class App:
    def __init__(self,root):
        self.root=root; self.root.title('Gerber Local Font Matcher'); self.root.geometry('1100x760')
        self.events=queue.Queue(); self.busy=False; self.cancel=threading.Event()
        self.rows=[]; self.font_paths=[]; self.font_names=[]; self.results=[]; self.records=[]
        self.pathvar=tk.StringVar(value=str(APP_DIR/'Gerber_Font_Inventory.csv'))
        self.foldervar=tk.StringVar(value=str(Path.home()/'Downloads'))
        self.threshold=tk.IntVar(value=78); self.max_per=tk.IntVar(value=15)
        self.status=tk.StringVar(value='Choose an inventory and a folder. All scanning happens on this computer.')
        outer=ttk.Frame(root,padding=12);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='Gerber Local Font Matcher',font=('Segoe UI',16,'bold')).pack(anchor='w')
        ttk.Label(outer,text='Scans actual TTF/OTF/TTC/OTC files. No font installation or online upload.').pack(anchor='w',pady=(0,10))
        self._browse_line(outer,'Gerber inventory (CSV or XLSX)',self.pathvar,lambda: filedialog.askopenfilename(filetypes=[('Inventories','*.csv *.xlsx *.xlsm')]))
        self._browse_line(outer,'Extracted font folder (include subfolders)',self.foldervar,lambda: filedialog.askdirectory())
        ctrl=ttk.Frame(outer);ctrl.pack(fill='x',pady=8)
        ttk.Label(ctrl,text='Minimum similarity').pack(side='left')
        ttk.Spinbox(ctrl,from_=40,to=100,width=5,textvariable=self.threshold).pack(side='left',padx=5)
        ttk.Label(ctrl,text='Candidates per Gerber font').pack(side='left',padx=(18,0))
        ttk.Spinbox(ctrl,from_=1,to=100,width=5,textvariable=self.max_per).pack(side='left',padx=5)
        self.scan_btn=ttk.Button(ctrl,text='1. Scan and find matches',command=self.start_scan); self.scan_btn.pack(side='left',padx=15)
        ttk.Button(ctrl,text='Stop scan',command=self.cancel.set).pack(side='left')
        filters=ttk.Frame(outer);filters.pack(fill='x',pady=5)
        ttk.Label(filters,text='Filter matches').pack(side='left');self.filter=tk.StringVar()
        field=ttk.Entry(filters,textvariable=self.filter,width=35);field.pack(side='left',padx=8);field.bind('<KeyRelease>',lambda e:self.refresh())
        ttk.Button(filters,text='Select visible',command=lambda:self.toggle_visible(True)).pack(side='left',padx=3)
        ttk.Button(filters,text='Unselect visible',command=lambda:self.toggle_visible(False)).pack(side='left',padx=3)
        ttk.Button(filters,text='Export all candidates CSV',command=self.export_csv).pack(side='right')
        columns=('check','gerber','score','candidate','path')
        frame=ttk.Frame(outer);frame.pack(fill='both',expand=True,pady=5)
        self.tree=ttk.Treeview(frame,columns=columns,show='headings',selectmode='extended')
        for key,label,w in [('check','Pick',52),('gerber','Gerber name',225),('score','Score',65),('candidate','Matching font name',210),('path','Actual file path',440)]:
            self.tree.heading(key,text=label);self.tree.column(key,width=w,stretch=(key=='path'))
        self.tree.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);scroll.pack(side='right',fill='y');self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind('<Double-1>',self.toggle_row);self.tree.bind('<space>',self.toggle_row)
        ttk.Label(outer,text='Double-click a result to check/uncheck. High scores are name matches, NOT verified outline matches.').pack(anchor='w')
        bottom=ttk.Frame(outer);bottom.pack(fill='x',pady=7)
        ttk.Button(bottom,text='2. ZIP selected files + manifest',command=self.make_zip).pack(side='left')
        ttk.Button(bottom,text='Open selected font folder',command=self.open_folder).pack(side='left',padx=10)
        ttk.Label(outer,textvariable=self.status,wraplength=1050).pack(anchor='w')
        self.root.after(150,self.poll)
    def _browse_line(self,parent,label,var,choose):
        fr=ttk.Frame(parent);fr.pack(fill='x',pady=2)
        ttk.Label(fr,text=label,width=38).pack(side='left')
        ttk.Entry(fr,textvariable=var).pack(side='left',fill='x',expand=True,padx=5)
        def doit():
            picked=choose()
            if picked: var.set(picked)
        ttk.Button(fr,text='Browse…',command=doit).pack(side='left')
    def run_async(self,fn):
        if self.busy: return
        self.busy=True;self.cancel.clear();self.scan_btn.configure(state='disabled')
        def work():
            try: fn()
            except Exception as e:self.events.put(('error',str(e)+'\n'+traceback.format_exc(limit=3)))
            finally:self.events.put(('finish',None))
        threading.Thread(target=work,daemon=True).start()
    def start_scan(self):
        inv=Path(self.pathvar.get()); folder=Path(self.foldervar.get())
        if not inv.is_file():return messagebox.showerror('Inventory missing','Select a valid Gerber inventory file.')
        if not folder.is_dir():return messagebox.showerror('Folder missing','Select the extracted font folder.')
        self.run_async(lambda:self.scan(inv,folder))
    def scan(self,inv,folder):
        records=load_inventory(inv)
        if not records: raise RuntimeError('No Gerber font names found in the inventory.')
        self.events.put(('status',f'Inventory: {len(records)} entries. Finding font files…'))
        paths=[]
        for root,dirs,files in os.walk(folder):
            if self.cancel.is_set(): return
            dirs[:]=[d for d in dirs if not d.startswith('.')]
            for f in files:
                if Path(f).suffix.lower() in EXTENSIONS: paths.append(Path(root)/f)
        self.events.put(('status',f'Found {len(paths):,} font files. Reading internal names (cached on later scans)…'))
        conn=connect_db(); names=[]; used=[]; invalid=0
        for idx,path in enumerate(paths):
            if self.cancel.is_set():conn.commit();conn.close();return
            try:
                st=path.stat();key=str(path)
                rec=conn.execute('SELECT names,error,size,mtime FROM fonts WHERE path=?',(key,)).fetchone()
                if rec and rec[2]==st.st_size and rec[3]==st.st_mtime:
                    fnames=rec[0].split('\x1f') if rec[0] else []
                    err=rec[1]
                else:
                    try:fnames=read_font(path);err=''
                    except Exception as e:fnames=[];err=str(e)[:200]
                    conn.execute('INSERT OR REPLACE INTO fonts(path,size,mtime,names,error) VALUES (?,?,?,?,?)',(key,st.st_size,st.st_mtime,'\x1f'.join(fnames),err))
                if err:invalid+=1;continue
                fnames.insert(0,path.stem)
                fnames=list(dict.fromkeys(fnames))
                used.append(str(path));names.append(fnames)
            except (OSError,ValueError): invalid+=1
            if idx%1500==0:
                conn.commit();self.events.put(('status',f'Scanned {idx+1:,} / {len(paths):,} files; {invalid:,} unreadable.'))
        conn.commit();conn.close()
        self.events.put(('status',f'Comparing {len(used):,} readable fonts with {len(records)} Gerber names…'))
        matches=select_candidates(records,names,int(self.threshold.get()),int(self.max_per.get()))
        for m in matches:m.update(path=used[m['font_id']],picked=(m['score']>=95))
        self.events.put(('results',(records,used,names,matches,invalid,len(paths))))
    def poll(self):
        try:
            for _ in range(50):
                t,v=self.events.get_nowait()
                if t=='status':self.status.set(v)
                if t=='error':messagebox.showerror('Problem',v);self.status.set('Stopped due to error')
                if t=='results':
                    self.records,self.font_paths,self.font_names,self.results,bad,count=v
                    self.refresh(); self.status.set(f'{len(self.results):,} candidate rows from {count:,} font files ({bad:,} unreadable). Only high-confidence names are preselected. Review before zipping.')
                if t=='finish':self.busy=False;self.scan_btn.configure(state='normal')
        except queue.Empty:pass
        self.root.after(150,self.poll)
    def refresh(self):
        needle=self.filter.get().casefold()
        self.tree.delete(*self.tree.get_children())
        limit=10000
        visible=0
        for i,r in enumerate(self.results):
            if needle and needle not in (' '.join([r['gerber'],r['match'],r['path']])).casefold():continue
            self.tree.insert('', 'end', iid=str(i),values=('☑' if r['picked'] else '☐',r['gerber'],r['score'],r['match'],r['path']))
            visible+=1
            if visible>=limit:break
    def toggle_row(self,e=None):
        ids=self.tree.selection()
        if e is not None and getattr(e,'type',None)== '4':
            target=self.tree.identify_row(e.y)
            if target:ids=(target,)
        for sid in ids:
            r=self.results[int(sid)];r['picked']=not r['picked']
            self.tree.set(sid,'check','☑' if r['picked'] else '☐')
    def toggle_visible(self,value):
        for sid in self.tree.get_children():
            self.results[int(sid)]['picked']=value
            self.tree.set(sid,'check','☑' if value else '☐')
    def export_csv(self):
        if not self.results:return messagebox.showinfo('Scan first','Run the scan first.')
        dest=filedialog.asksaveasfilename(defaultextension='.csv',initialfile='Gerber_All_Match_Candidates.csv',filetypes=[('CSV','*.csv')])
        if dest:
            with open(dest,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f);w.writerow(['Selected','Gerber Name','GSF Filename','Clean Name','Score','Matched Font Name','Full Path'])
                for r in self.results:w.writerow([r['picked'],r['gerber'],r['gsf'],r['clean'],r['score'],r['match'],r['path']])
            messagebox.showinfo('Exported',f'Saved {len(self.results):,} rows.')
    def make_zip(self):
        picked=[r for r in self.results if r['picked']]
        if not picked:return messagebox.showinfo('Nothing selected','Select matching font files first.')
        if not messagebox.askyesno('Confirm licensing',f'{len(picked)} candidate rows selected.\n\nOnly package fonts that your organization is licensed to store/copy. Many archive fonts have unknown licenses.\n\nContinue?'):return
        dest=filedialog.asksaveasfilename(defaultextension='.zip',initialfile='Gerber_Matched_Font_Candidates.zip',filetypes=[('ZIP archive','*.zip')])
        if not dest:return
        self.run_async(lambda:self.zip_work(dest,picked))
    def zip_work(self,dest,picked):
        unique={r['path']:r for r in picked}; rows=[];fail=[]
        with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
            for i,(path,rep) in enumerate(unique.items()):
                if self.cancel.is_set():break
                try:
                    p=Path(path);digest=hashlib.sha1(path.encode('utf-8')).hexdigest()[:10]
                    arcname=f'Fonts/{digest}_{p.name}'
                    info=zipfile.ZipInfo(arcname, date_time=(1980,1,1,0,0,0))
                    info.compress_type=zipfile.ZIP_DEFLATED
                    with p.open('rb') as src, z.open(info, 'w', force_zip64=True) as dst:
                        shutil.copyfileobj(src,dst,1024*1024)
                    rows.append((path,arcname))
                except Exception as e:fail.append((path,str(e)))
                if i%100==0:self.events.put(('status',f'Packaging {i+1:,} / {len(unique):,} unique files…'))
            mapping={p:arc for p,arc in rows}
            import io
            report=io.StringIO();w=csv.writer(report)
            w.writerow(['Gerber font','Original GSF','Normalized Gerber name','Match score','Candidate font name','Original source path','ZIP path'])
            for r in picked:
                if r['path'] in mapping:w.writerow([r['gerber'],r['gsf'],r['clean'],r['score'],r['match'],r['path'],mapping[r['path']]])
            z.writestr('MATCH_REPORT.csv',report.getvalue().encode('utf-8-sig'))
            z.writestr('README.txt','These are name-based candidate matches, NOT verified equivalent outlines. Fonts must be appropriately licensed before use or redistribution. The ZIP contains only selected files, and no fonts were installed.\n')
            if fail:
                z.writestr('FAILED_FILES.txt','\n'.join(f'{p}: {e}' for p,e in fail))
        self.events.put(('status',f'ZIP created: {dest} | {len(rows)} unique files, {len(fail)} failures.'))
    def open_folder(self):
        ids=self.tree.selection()
        if not ids:return
        p=Path(self.results[int(ids[0])]['path'])
        if os.name=='nt':os.startfile(str(p.parent))
        else:messagebox.showinfo('File',str(p))

if __name__=='__main__':
    if TTFont is None:
        print('Missing fonttools. Run INSTALL_AND_START.bat');
        try: input('Press Enter to close...')
        except:pass
        sys.exit(1)
    root=tk.Tk();App(root);root.mainloop()
