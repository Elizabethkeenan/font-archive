@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -m pip install --user fonttools openpyxl
  py font_matcher.py
) else (
  where python >nul 2>&1
  if errorlevel 1 (echo Python 3 is required. Install it from python.org and re-run.& pause & exit /b 1)
  python -m pip install --user fonttools openpyxl
  python font_matcher.py
)
if errorlevel 1 pause
