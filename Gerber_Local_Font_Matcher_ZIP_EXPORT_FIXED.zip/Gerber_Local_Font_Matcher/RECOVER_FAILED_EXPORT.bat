@echo off
cd /d "%~dp0"
py -3 RECOVER_FAILED_EXPORT.py
if errorlevel 1 python RECOVER_FAILED_EXPORT.py
pause
