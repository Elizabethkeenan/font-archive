"""Recover font files from a previous failed export without rescanning. Windows Python 3."""
import csv, hashlib, io, os, shutil, zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

def main():
    app=tk.Tk();app.withdraw()
    source=filedialog.askopenfilename(title='Choose the previous failed Gerber candidates ZIP',filetypes=[('ZIP files','*.zip')])
    if not source:return
    with zipfile.ZipFile(source) as z:
        if 'FAILED_FILES.txt' not in z.namelist():
            messagebox.showerror('No failed file list','This ZIP has no FAILED_FILES.txt');return
        failures=z.read('FAILED_FILES.txt').decode('utf-8-sig',errors='replace').splitlines()
    paths=[]
    for line in failures:
        path=line.split(': ZIP does not support timestamps before 1980')[0].strip()
        if path and path not in paths:paths.append(path)
    dest=filedialog.asksaveasfilename(title='Save recovered font ZIP',initialfile='Gerber_Recovered_Export.zip',defaultextension='.zip',filetypes=[('ZIP files','*.zip')])
    if not dest:return
    result=[];errors=[]
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,allowZip64=True) as z:
        for i,path in enumerate(paths,1):
            p=Path(path)
            try:
                if not p.is_file():raise FileNotFoundError('Original font file no longer exists at that location')
                arc='Fonts/'+hashlib.sha1(path.encode('utf-8')).hexdigest()[:10]+'_'+p.name
                info=zipfile.ZipInfo(arc, date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                with p.open('rb') as src,z.open(info,'w',force_zip64=True) as dst:shutil.copyfileobj(src,dst,1024*1024)
                result.append([str(p),arc])
            except Exception as e:errors.append([path,str(e)])
            if i%25==0:print(f'Processed {i}/{len(paths)}...')
        report=io.StringIO();w=csv.writer(report);w.writerow(['Original source path','ZIP path']);w.writerows(result)
        z.writestr('RECOVERED_PATHS.csv',report.getvalue().encode('utf-8-sig'))
        if errors:
            report=io.StringIO();w=csv.writer(report);w.writerow(['Original source path','Error']);w.writerows(errors)
            z.writestr('STILL_FAILED.csv',report.getvalue().encode('utf-8-sig'))
    messagebox.showinfo('Complete',f'Recovered {len(result)} fonts.\nStill missing/errors: {len(errors)}\n\n{dest}\n\nNote: the original failed export did not retain name-match scores. This recovery ZIP contains files and paths only.')
    print('Done',len(result),'successes',len(errors),'failures')

if __name__=='__main__':main()
